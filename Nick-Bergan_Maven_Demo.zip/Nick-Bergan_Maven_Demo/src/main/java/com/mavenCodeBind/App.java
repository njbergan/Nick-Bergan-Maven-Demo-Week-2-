//Nick Bergan
//This program holds functions that are called by the Hello_World program, it returns different variable data.
package com.mavenCodeBind;

public class App {
	
	public App() {
		
	}
	
	public String Sample() {
		return "sample";
	}
	public double hue = 5;
}
