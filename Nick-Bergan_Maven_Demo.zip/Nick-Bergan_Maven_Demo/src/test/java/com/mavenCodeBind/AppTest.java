//Nick Bergan
//This program is a part of maven, it calls main java files and tests them.
package com.mavenCodeBind;

//import static org.junit.Assert.*;

import org.junit.Test;

public class AppTest {

	@Test
	public void test() {
		
		
			com.mavenCodeBind.Hello_World.main(null);
			
			//fail("Test message");
		
		
	}

}
